plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tik2whats.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tik2whats.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.2.0"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.9.3")
}
