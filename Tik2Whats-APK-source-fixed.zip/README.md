# Tik2Whats — Android project

Aplicación Android experimental para importar imágenes y preparar un paquete de stickers estáticos para WhatsApp.

## Estado
- Importación de imágenes desde el selector de Android y desde el menú Compartir.
- Conversión de imagen a WebP cuadrado de 512 × 512 px y compresión con límite aproximado de 100 KB.
- Gestión de 3 a 30 stickers estáticos.
- Integración inicial con el mecanismo de proveedor de contenido de WhatsApp.
- Flujo de GitHub Actions para compilar un APK de depuración.

No extrae automáticamente stickers privados de TikTok. La importación de GIF/vídeo animado no está implementada; en esta versión se trabajan imágenes estáticas. El proyecto no se ha compilado ni probado en dispositivo en este entorno, así que pueden aparecer errores que habrá que corregir.

## Compilación automática
1. Crea un repositorio GitHub vacío llamado `Tik2Whats`.
2. Sube **el contenido de esta carpeta** a la raíz del repositorio (incluida la carpeta oculta `.github`). No subas solamente el ZIP como archivo.
3. En GitHub, abre **Actions** y selecciona **Build Tik2Whats APK**. Ejecuta **Run workflow** si no se inició automáticamente tras subir los archivos.
4. Cuando finalice correctamente, abre la ejecución y descarga el artefacto `Tik2Whats-debug-APK`. Dentro estará `app-debug.apk`.

El APK debug es para pruebas; no es una versión firmada para publicar en Google Play.
